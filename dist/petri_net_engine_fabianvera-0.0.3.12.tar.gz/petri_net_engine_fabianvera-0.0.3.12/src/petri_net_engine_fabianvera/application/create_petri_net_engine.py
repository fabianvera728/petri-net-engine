class CreatePetriNetEngine:

    def __init__(self):
        pass

