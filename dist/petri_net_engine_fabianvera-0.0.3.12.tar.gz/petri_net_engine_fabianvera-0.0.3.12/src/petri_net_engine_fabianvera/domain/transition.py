class Transition:

    def __init__(self, transition_id: str, name: str):
        self.transition_id = transition_id
        self.name = name
