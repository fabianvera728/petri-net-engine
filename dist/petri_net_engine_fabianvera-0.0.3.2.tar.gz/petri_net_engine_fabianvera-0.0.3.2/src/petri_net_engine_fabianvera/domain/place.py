class Place:

    def __init__(self, place_id: str, name: str, tokens: int):
        self.place_id = place_id
        self.name = name
        self.tokens = tokens
